import flask
import subprocess
import os
import json
import time
import logging
from datetime import datetime
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = flask.Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

# Global stats
stats = {
    'total_encodings': 0,
    'successful_encodings': 0,
    'failed_encodings': 0,
    'start_time': datetime.now().isoformat()
}

@app.route('/')
def docs():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>FFmpeg CUDA API - Production</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                margin: 0; 
                padding: 20px; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #333;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                background: white;
                border-radius: 10px;
                padding: 30px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            }
            h1 { 
                color: #2c3e50; 
                text-align: center;
                margin-bottom: 10px;
            }
            .status-bar {
                background: #27ae60;
                color: white;
                padding: 15px;
                border-radius: 5px;
                text-align: center;
                margin: 20px 0;
                font-weight: bold;
            }
            h2 { 
                color: #34495e; 
                border-bottom: 2px solid #3498db;
                padding-bottom: 10px;
            }
            .endpoint {
                background: #f8f9fa;
                margin: 15px 0;
                padding: 15px;
                border-left: 4px solid #3498db;
                border-radius: 0 5px 5px 0;
            }
            .method {
                background: #e74c3c;
                color: white;
                padding: 3px 8px;
                border-radius: 3px;
                font-size: 12px;
                font-weight: bold;
                margin-right: 10px;
            }
            .method.get { background: #27ae60; }
            .method.post { background: #e74c3c; }
            pre { 
                background: #2c3e50; 
                color: #ecf0f1;
                padding: 15px; 
                border-radius: 5px; 
                overflow-x: auto;
                font-size: 14px;
            }
            .grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .card {
                background: #f8f9fa;
                padding: 20px;
                border-radius: 8px;
                border: 1px solid #dee2e6;
            }
            .btn {
                background: #3498db;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
                margin: 5px;
            }
            .btn:hover { background: #2980b9; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚀 FFmpeg CUDA API</h1>
            <div class="status-bar">
                Production Ready | RTX 4090 Accelerated | Gunicorn Powered
            </div>
            
            <div class="grid">
                <div class="card">
                    <h3>🎯 Quick Actions</h3>
                    <a href="/health" class="btn">Health Check</a>
                    <a href="/files" class="btn">List Files</a>
                    <a href="/info" class="btn">System Info</a>
                    <a href="/stats" class="btn">Statistics</a>
                </div>
                <div class="card">
                    <h3>📊 Performance</h3>
                    <p><strong>GPU:</strong> NVIDIA RTX 4090</p>
                    <p><strong>Acceleration:</strong> NVENC/NVDEC</p>
                    <p><strong>Expected Speed:</strong> 300-500+ FPS (1080p)</p>
                </div>
            </div>
            
            <h2>📋 API Endpoints</h2>
            
            <div class="endpoint">
                <span class="method get">GET</span><strong>/health</strong>
                <p>Check API health, status, and system information</p>
            </div>
            
            <div class="endpoint">
                <span class="method get">GET</span><strong>/files</strong>
                <p>List all available video files in the workspace with size information</p>
            </div>
            
            <div class="endpoint">
                <span class="method get">GET</span><strong>/info</strong>
                <p>Display FFmpeg version, capabilities, and hardware acceleration status</p>
            </div>
            
            <div class="endpoint">
                <span class="method get">GET</span><strong>/stats</strong>
                <p>Show encoding statistics and performance metrics</p>
            </div>
            
            <div class="endpoint">
                <span class="method post">POST</span><strong>/encode</strong>
                <p>Encode video with NVIDIA NVENC hardware acceleration</p>
            </div>
            
            <h2>🎬 Usage Examples</h2>
            
            <h3>List Available Files:</h3>
            <pre>curl http://localhost:15959/files</pre>
            
            <h3>Basic Video Encoding:</h3>
            <pre>curl -X POST http://localhost:15959/encode \\
  -H "Content-Type: application/json" \\
  -d '{
    "input": "input_video.mp4",
    "output": "encoded_output.mp4"
  }'</pre>
            
            <h3>High Quality Encoding:</h3>
            <pre>curl -X POST http://localhost:15959/encode \\
  -H "Content-Type: application/json" \\
  -d '{
    "input": "source.mp4",
    "output": "high_quality.mp4",
    "preset": "slow",
    "crf": "18"
  }'</pre>
            
            <h3>4K Upscaling:</h3>
            <pre>curl -X POST http://localhost:15959/encode \\
  -H "Content-Type: application/json" \\
  -d '{
    "input": "1080p_video.mp4",
    "output": "4k_video.mp4",
    "scale": "3840x2160",
    "preset": "medium"
  }'</pre>
            
            <h2>⚙️ Encoding Parameters</h2>
            <div class="grid">
                <div class="card">
                    <h4>Required Parameters</h4>
                    <p><strong>input:</strong> Input video filename</p>
                    <p><strong>output:</strong> Output video filename</p>
                </div>
                <div class="card">
                    <h4>Optional Parameters</h4>
                    <p><strong>preset:</strong> fast, medium, slow (default: fast)</p>
                    <p><strong>crf:</strong> Quality 18-28 (default: 23)</p>
                    <p><strong>scale:</strong> Resolution e.g., "1920x1080"</p>
                    <p><strong>bitrate:</strong> Video bitrate e.g., "5M"</p>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 40px; color: #7f8c8d;">
                <p>Powered by FFmpeg + NVIDIA CUDA | Built for Production</p>
            </div>
        </div>
    </body>
    </html>
    '''

@app.route('/health')
def health():
    try:
        # Test FFmpeg
        result = subprocess.run(['ffmpeg', '-version'], capture_output=True, text=True, timeout=5)
        ffmpeg_ok = result.returncode == 0
        
        # Test GPU access
        gpu_result = subprocess.run(['nvidia-smi', '--query-gpu=name', '--format=csv,noheader'], 
                                  capture_output=True, text=True, timeout=5)
        gpu_ok = gpu_result.returncode == 0
        gpu_name = gpu_result.stdout.strip() if gpu_ok else "Not detected"
        
        return {
            'status': 'healthy' if ffmpeg_ok and gpu_ok else 'degraded',
            'timestamp': datetime.now().isoformat(),
            'ffmpeg': 'ok' if ffmpeg_ok else 'error',
            'gpu': gpu_name,
            'gpu_status': 'ok' if gpu_ok else 'error',
            'workspace': '/workspace',
            'mode': 'production',
            'server': 'gunicorn',
            'api_version': '2.0'
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return {'status': 'error', 'message': str(e)}, 500

@app.route('/files')
def list_files():
    try:
        files = []
        workspace = '/workspace'
        
        if not os.path.exists(workspace):
            return {'error': 'Workspace not found', 'workspace': workspace}, 404
            
        for f in os.listdir(workspace):
            if f.lower().endswith(('.mp4', '.avi', '.mov', '.mkv', '.webm', '.flv', '.m4v', '.wmv', '.3gp')):
                filepath = os.path.join(workspace, f)
                try:
                    stat = os.stat(filepath)
                    files.append({
                        'name': f,
                        'size_mb': round(stat.st_size / 1024 / 1024, 1),
                        'size_bytes': stat.st_size,
                        'modified': datetime.fromtimestamp(stat.st_mtime).isoformat()
                    })
                except OSError:
                    continue
        
        return {
            'files': sorted(files, key=lambda x: x['name']),
            'total': len(files),
            'workspace': workspace,
            'total_size_mb': round(sum(f['size_mb'] for f in files), 1)
        }
    except Exception as e:
        logger.error(f"File listing failed: {e}")
        return {'error': str(e), 'workspace': '/workspace'}, 500

@app.route('/info')
def ffmpeg_info():
    try:
        info = {}
        
        # FFmpeg version
        version_result = subprocess.run(['ffmpeg', '-version'], capture_output=True, text=True, timeout=10)
        if version_result.returncode == 0:
            info['ffmpeg_version'] = version_result.stdout.split('\n')[0]
        
        # Hardware accelerators
        hwaccel_result = subprocess.run(['ffmpeg', '-hwaccels'], capture_output=True, text=True, timeout=10)
        if hwaccel_result.returncode == 0:
            info['hardware_accelerators'] = [line.strip() for line in hwaccel_result.stdout.split('\n')[1:] if line.strip()]
        
        # NVENC encoders
        encoders_result = subprocess.run(['ffmpeg', '-encoders'], capture_output=True, text=True, timeout=10)
        if encoders_result.returncode == 0:
            nvenc_encoders = []
            for line in encoders_result.stdout.split('\n'):
                if 'nvenc' in line.lower() and line.strip():
                    nvenc_encoders.append(line.strip())
            info['nvenc_encoders'] = nvenc_encoders
        
        # GPU info
        gpu_result = subprocess.run(['nvidia-smi', '--query-gpu=name,memory.total,memory.used', '--format=csv,noheader,nounits'], 
                                  capture_output=True, text=True, timeout=10)
        if gpu_result.returncode == 0:
            gpu_data = gpu_result.stdout.strip().split(', ')
            if len(gpu_data) >= 3:
                info['gpu'] = {
                    'name': gpu_data[0],
                    'memory_total_mb': int(gpu_data[1]),
                    'memory_used_mb': int(gpu_data[2]),
                    'memory_free_mb': int(gpu_data[1]) - int(gpu_data[2])
                }
        
        info['cuda_available'] = 'cuda' in info.get('hardware_accelerators', [])
        
        return info
    except Exception as e:
        logger.error(f"Info gathering failed: {e}")
        return {'error': str(e)}, 500

@app.route('/stats')
def get_stats():
    uptime_seconds = (datetime.now() - datetime.fromisoformat(stats['start_time'])).total_seconds()
    return {
        **stats,
        'uptime_seconds': round(uptime_seconds, 1),
        'uptime_hours': round(uptime_seconds / 3600, 2),
        'success_rate': round((stats['successful_encodings'] / max(stats['total_encodings'], 1)) * 100, 1)
    }

@app.route('/encode', methods=['POST'])
def encode():
    start_time = time.time()
    stats['total_encodings'] += 1
    
    try:
        data = flask.request.json
        if not data:
            return {'status': 'error', 'message': 'No JSON data provided'}, 400
        
        # Validate required fields
        required_fields = ['input', 'output']
        for field in required_fields:
            if field not in data:
                return {'status': 'error', 'message': f'Missing required field: {field}'}, 400
        
        input_file = data['input']
        output_file = data['output']
        preset = data.get('preset', 'fast')
        crf = str(data.get('crf', '23'))
        scale = data.get('scale')
        bitrate = data.get('bitrate')
        
        # Add workspace prefix if not absolute path
        if not input_file.startswith('/'):
            input_file = f'/workspace/{input_file}'
        if not output_file.startswith('/'):
            output_file = f'/workspace/{output_file}'
        
        # Check if input file exists
        if not os.path.exists(input_file):
            available_files = []
            try:
                available_files = [f for f in os.listdir('/workspace') 
                                 if f.lower().endswith(('.mp4', '.avi', '.mov', '.mkv', '.webm', '.flv'))]
            except:
                pass
            
            return {
                'status': 'error', 
                'message': f'Input file not found: {input_file}',
                'available_files': available_files
            }, 404
        
        # Build FFmpeg command
        cmd = [
            'ffmpeg', '-y',
            '-hwaccel', 'cuda',
            '-i', input_file,
            '-c:v', 'h264_nvenc',
            '-preset', preset
        ]
        
        # Add quality settings
        if bitrate:
            cmd.extend(['-b:v', bitrate])
        else:
            cmd.extend(['-crf', crf])
        
        # Add scaling if specified
        if scale:
            cmd.extend(['-vf', f'scale_cuda={scale}'])
        
        # Audio settings
        cmd.extend(['-c:a', 'aac', '-b:a', '128k'])
        
        # Output file
        cmd.append(output_file)
        
        logger.info(f"Starting encoding: {' '.join(cmd)}")
        
        # Execute FFmpeg with timeout
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)  # 1 hour timeout
        
        processing_time = time.time() - start_time
        
        # Check if output file was created
        output_exists = os.path.exists(output_file)
        output_size = 0
        if output_exists:
            output_size = os.path.getsize(output_file)
            stats['successful_encodings'] += 1
        else:
            stats['failed_encodings'] += 1
        
        response = {
            'status': 'success' if result.returncode == 0 and output_exists else 'error',
            'returncode': result.returncode,
            'processing_time_seconds': round(processing_time, 2),
            'output_file_created': output_exists,
            'output_size_mb': round(output_size / 1024 / 1024, 1) if output_exists else 0,
            'command': ' '.join(cmd),
            'input_file': input_file,
            'output_file': output_file,
            'timestamp': datetime.now().isoformat()
        }
        
        # Include FFmpeg output for debugging if there was an error
        if result.returncode != 0 or not output_exists:
            response['ffmpeg_stdout'] = result.stdout
            response['ffmpeg_stderr'] = result.stderr
        
        logger.info(f"Encoding completed: {response['status']} in {processing_time:.2f}s")
        
        return response
        
    except subprocess.TimeoutExpired:
        stats['failed_encodings'] += 1
        logger.error("Encoding timeout")
        return {'status': 'error', 'message': 'Encoding timeout (1 hour limit)'}, 408
    except Exception as e:
        stats['failed_encodings'] += 1
        logger.error(f"Encoding failed: {e}")
        return {'status': 'error', 'message': str(e), 'timestamp': datetime.now().isoformat()}, 500

@app.errorhandler(404)
def not_found(error):
    return {'error': 'Endpoint not found', 'available_endpoints': ['/', '/health', '/files', '/info', '/stats', '/encode']}, 404

@app.errorhandler(500)
def internal_error(error):
    return {'error': 'Internal server error', 'message': str(error)}, 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)

